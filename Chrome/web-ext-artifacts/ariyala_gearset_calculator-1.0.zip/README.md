# Ariyala-Gearset-Calculator
Tallies Raid and Tome equipment, calculates tomestones required for a gearset
This is primarily just to get familiar with Chrome's extension development.
The extension simply parses through a gearset from Ariyala and neatly displays every Raid and Tome item used in the gearset, as well as some additonal information that may be useful to FFXIV players using the gearset.
